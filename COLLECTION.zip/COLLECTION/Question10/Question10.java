package COLLECTION.Question10;

public class Question10 {
	
	class Node {
		Integer key;
		Node left;
		Node right;
		Node(Integer key, Node left, Node right){
			this.key = key;
			this.left = left;
			this.right = right;
		}
	}
	
	public static void main(String args) {
		
	}

}
