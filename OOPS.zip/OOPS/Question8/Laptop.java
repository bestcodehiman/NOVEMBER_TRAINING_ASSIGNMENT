package OOPS.Question8;

public class Laptop extends Electronics {
	public Laptop(int id, String semiconductorType, String dateOfManufacturing) {
		super(id, semiconductorType, dateOfManufacturing);
	}
}
