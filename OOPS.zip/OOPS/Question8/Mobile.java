package OOPS.Question8;

public class Mobile extends Electronics {
	public Mobile(int id, String semiconductorType, String dateOfManufacturing) {
		super(id, semiconductorType, dateOfManufacturing);
	}
}
