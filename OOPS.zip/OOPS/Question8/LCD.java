package OOPS.Question8;

public class LCD extends Electronics{

	public LCD(int id, String semiconductorType, String dateOfManufacturing) {
        super(id, semiconductorType, dateOfManufacturing);
    }
}
