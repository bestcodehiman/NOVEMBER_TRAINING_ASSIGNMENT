package OOPS.Question7;

abstract class Parent {
	
	public abstract void compareTo(String input1, String input2);
}
