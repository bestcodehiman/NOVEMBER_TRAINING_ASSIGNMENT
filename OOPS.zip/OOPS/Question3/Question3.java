package OOPS.Question3;

public class Question3 {
	public static void main(String[] args) {

		Customer_Account_Statement customerAccountStatement = new Customer_Account_Statement(1, 6352442, "nitin",
				"01/01/2021", "01/01/2022", "branch_Obj", 20, 10000.36, 5000.89, "16/11/2022");

		System.out.println(customerAccountStatement);

	}
}
