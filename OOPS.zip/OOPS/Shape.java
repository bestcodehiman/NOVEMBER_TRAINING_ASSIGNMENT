package OOPS;

public interface Shape {
	
	Long area();

}
