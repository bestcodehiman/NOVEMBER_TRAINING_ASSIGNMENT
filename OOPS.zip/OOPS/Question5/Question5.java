package OOPS.Question5;

public class Question5 {
	public static void main(String[] args) {
		CalcAbs c = new Div();
		c.sum(10, 20);
		c.sub(10, 20);
		c.mul(10, 20);
		c.div(10, 20);

	}
}
