package OOPS.Question2;

public interface Shape {

	void area();
}
