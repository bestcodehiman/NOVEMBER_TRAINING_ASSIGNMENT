package JAVA8.LAMBDA;

class Question8 {
	
}
