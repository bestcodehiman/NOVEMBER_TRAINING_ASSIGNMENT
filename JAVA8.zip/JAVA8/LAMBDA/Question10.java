package JAVA8.LAMBDA;

public class Question10 {

}
