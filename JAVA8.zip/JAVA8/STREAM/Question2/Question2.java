package JAVA8.STREAM.Question2;

public class Question2 {
}
