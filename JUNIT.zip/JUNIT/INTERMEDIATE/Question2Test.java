package JUNIT.INTERMEDIATE;

public class Question2Test {

}
