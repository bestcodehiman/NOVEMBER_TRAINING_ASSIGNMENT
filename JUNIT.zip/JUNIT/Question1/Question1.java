package JUNIT.Question1;

public class Question1 {
	public Integer findSum(Integer arr[]) {
		return ((arr[0] + arr[arr.length - 1]) * arr.length) / 2;
	}
}
