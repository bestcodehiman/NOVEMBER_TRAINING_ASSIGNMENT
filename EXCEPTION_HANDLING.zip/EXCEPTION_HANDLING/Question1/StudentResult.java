package EXCEPTION_HANDLING.Question1;

public class StudentResult {
	Integer maths;
	Integer science;
	Integer computer;
	Double percentage;
	
	public Double getPercentage() {
		return percentage;
	}
	public void setPercentage(Double percentage) {
		this.percentage = percentage;
	}
	public Integer getMaths() {
		return maths;
	}
	public void setMaths(Integer maths) {
		this.maths = maths;
	}
	public Integer getScience() {
		return science;
	}
	public void setScience(Integer science) {
		this.science = science;
	}
	public Integer getComputer() {
		return computer;
	}
	public void setComputer(Integer computer) {
		this.computer = computer;
	}
	
}
