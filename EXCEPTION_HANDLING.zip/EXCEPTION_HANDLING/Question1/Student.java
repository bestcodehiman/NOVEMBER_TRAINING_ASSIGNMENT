package EXCEPTION_HANDLING.Question1;

public class Student {
	Integer rollno;
	String name;
	String address;
	StudentResult studentResult;

	public Integer getRollno() {
		return rollno;
	}

	public void setRollno(Integer rollno) {
		this.rollno = rollno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public StudentResult getStudentResult() {
		return studentResult;
	}

	public void setStudentResult(StudentResult studentResult) {
		this.studentResult = studentResult;
	}
	

}
